#include <iostream>
#include "Calculator.h"


int main() {
    Calculator *calc = new Calculator();
    Set misha = new Set("MISHA");
    calc->main_loop();
    return 0;

}